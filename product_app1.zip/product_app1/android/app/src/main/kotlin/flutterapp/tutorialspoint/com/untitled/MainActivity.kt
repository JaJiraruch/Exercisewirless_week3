package flutterapp.tutorialspoint.com.untitled

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
