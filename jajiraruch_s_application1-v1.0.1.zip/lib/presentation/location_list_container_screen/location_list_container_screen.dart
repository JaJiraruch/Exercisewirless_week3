import 'package:flutter/material.dart';
import 'package:jajiraruch_s_application1/core/app_export.dart';
import 'package:jajiraruch_s_application1/presentation/location_list_page/location_list_page.dart';
import 'package:jajiraruch_s_application1/widgets/custom_bottom_bar.dart';

// ignore_for_file: must_be_immutable
class LocationListContainerScreen extends StatelessWidget {
  LocationListContainerScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Navigator(
                key: navigatorKey,
                initialRoute: AppRoutes.locationListPage,
                onGenerateRoute: (routeSetting) => PageRouteBuilder(
                    pageBuilder: (ctx, ani, ani1) =>
                        getCurrentPage(routeSetting.name!),
                    transitionDuration: Duration(seconds: 0))),
            bottomNavigationBar: _buildBottomBar(context)));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Locationicon:
        return AppRoutes.locationListPage;
      case BottomBarEnum.Mapicon:
        return "/";
      case BottomBarEnum.Rankicon:
        return "/";
      case BottomBarEnum.Newsicon:
        return "/";
      case BottomBarEnum.Accounticon:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.locationListPage:
        return LocationListPage();
      default:
        return DefaultWidget();
    }
  }
}
