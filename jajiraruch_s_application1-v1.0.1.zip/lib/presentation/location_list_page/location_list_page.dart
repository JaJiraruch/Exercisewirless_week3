import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:jajiraruch_s_application1/core/app_export.dart';
import 'package:jajiraruch_s_application1/widgets/app_bar/appbar_leading_image.dart';
import 'package:jajiraruch_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:jajiraruch_s_application1/widgets/app_bar/appbar_trailing_image.dart';
import 'package:jajiraruch_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:jajiraruch_s_application1/widgets/custom_icon_button.dart';
import 'package:jajiraruch_s_application1/widgets/custom_outlined_button.dart';

// ignore_for_file: must_be_immutable
class LocationListPage extends StatelessWidget {
  const LocationListPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: 776.v,
          width: double.maxFinite,
          decoration: AppDecoration.fillWhiteA,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgBg,
                height: 776.v,
                width: 393.h,
                alignment: Alignment.topCenter,
              ),
              Align(
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildHeader(context),
                    SizedBox(height: 86.v),
                    _buildContent(context),
                    Spacer(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 11.v),
      child: Column(
        children: [
          SizedBox(height: 6.v),
          Padding(
            padding: EdgeInsets.only(
              left: 42.h,
              right: 25.h,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgImage29,
                  height: 26.v,
                  width: 64.h,
                  margin: EdgeInsets.only(
                    top: 3.v,
                    bottom: 4.v,
                  ),
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgImage28,
                  height: 33.v,
                  width: 107.h,
                ),
              ],
            ),
          ),
          SizedBox(height: 7.v),
          CustomAppBar(
            leadingWidth: 58.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgSearchIcon,
              margin: EdgeInsets.only(
                left: 36.h,
                top: 1.v,
                bottom: 6.v,
              ),
            ),
            centerTitle: true,
            title: AppbarTitle(
              text: "Air Pollution",
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgNotificationIcon,
                margin: EdgeInsets.fromLTRB(38.h, 3.v, 38.h, 7.v),
              ),
            ],
          ),
          SizedBox(height: 24.v),
          Text(
            "Places",
            style: CustomTextStyles.titleSmallNewsreaderBluegray300,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContent(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 21.h),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(right: 8.h),
            padding: EdgeInsets.symmetric(
              horizontal: 8.h,
              vertical: 6.v,
            ),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: fs.Svg(
                  ImageConstant.imgGroup5,
                ),
                fit: BoxFit.cover,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(right: 6.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 104.h,
                        margin: EdgeInsets.only(bottom: 20.v),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgSunIcon,
                              height: 34.v,
                              width: 30.h,
                            ),
                            Text(
                              "29°",
                              style: theme.textTheme.titleLarge,
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 22.v),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: 3.v),
                              child: Column(
                                children: [
                                  Text(
                                    "Mahidol University",
                                    style: theme.textTheme.bodyMedium,
                                  ),
                                  Text(
                                    "Salaya, Thailand",
                                    style:
                                        CustomTextStyles.bodySmallBluegray300,
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                left: 19.h,
                                bottom: 8.v,
                              ),
                              child: CustomIconButton(
                                height: 24.adaptSize,
                                width: 24.adaptSize,
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgArrowIconUp,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8.v),
                Padding(
                  padding: EdgeInsets.only(
                    left: 9.h,
                    right: 22.h,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      SizedBox(
                        width: 165.h,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: 88.h,
                                  child: Text(
                                    "Unhealthy for\nsensitive groups",
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                    style: CustomTextStyles.bodySmall12,
                                  ),
                                ),
                                SizedBox(height: 7.v),
                                CustomImageView(
                                  imagePath: ImageConstant.imgBadIcon,
                                  height: 85.v,
                                  width: 90.h,
                                ),
                                SizedBox(height: 2.v),
                                Padding(
                                  padding: EdgeInsets.only(left: 23.h),
                                  child: Text(
                                    "119",
                                    style: theme.textTheme.headlineSmall,
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: 20.v,
                                bottom: 4.v,
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    "Tue",
                                    style: theme.textTheme.bodyMedium,
                                  ),
                                  SizedBox(height: 8.v),
                                  Container(
                                    width: 46.h,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 7.h,
                                      vertical: 2.v,
                                    ),
                                    decoration:
                                        AppDecoration.fillYellow.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.circleBorder9,
                                    ),
                                    child: Text(
                                      "51-100",
                                      style: theme.textTheme.bodySmall,
                                    ),
                                  ),
                                  SizedBox(height: 10.v),
                                  CustomImageView(
                                    imagePath: ImageConstant.imgImage12,
                                    height: 34.adaptSize,
                                    width: 34.adaptSize,
                                  ),
                                  SizedBox(height: 8.v),
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "33",
                                          style: CustomTextStyles
                                              .bodyMediumff000000,
                                        ),
                                        TextSpan(
                                          text: "°",
                                          style: CustomTextStyles
                                              .bodyMediumff000000,
                                        ),
                                      ],
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                  SizedBox(height: 8.v),
                                  Text(
                                    "23°",
                                    style:
                                        CustomTextStyles.bodyMediumBluegray300,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 10.h),
                        child: SizedBox(
                          height: 165.v,
                          child: VerticalDivider(
                            width: 1.h,
                            thickness: 1.v,
                            indent: 14.h,
                            endIndent: 2.h,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 8.h,
                          top: 20.v,
                          bottom: 4.v,
                        ),
                        child: Column(
                          children: [
                            Text(
                              "Wed",
                              style: theme.textTheme.bodyMedium,
                            ),
                            SizedBox(height: 8.v),
                            Container(
                              width: 46.h,
                              padding: EdgeInsets.symmetric(
                                horizontal: 6.h,
                                vertical: 2.v,
                              ),
                              decoration: AppDecoration.fillDeepOrange.copyWith(
                                borderRadius: BorderRadiusStyle.circleBorder9,
                              ),
                              child: Text(
                                "101-150",
                                style: theme.textTheme.bodySmall,
                              ),
                            ),
                            SizedBox(height: 14.v),
                            CustomImageView(
                              imagePath: ImageConstant.imgImage13,
                              height: 30.v,
                              width: 37.h,
                              alignment: Alignment.centerRight,
                              margin: EdgeInsets.only(right: 3.h),
                            ),
                            SizedBox(height: 8.v),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "34",
                                    style: CustomTextStyles.bodyMediumff000000,
                                  ),
                                  TextSpan(
                                    text: "°",
                                    style: CustomTextStyles.bodyMediumff000000,
                                  ),
                                ],
                              ),
                              textAlign: TextAlign.left,
                            ),
                            SizedBox(height: 7.v),
                            Text(
                              "24°",
                              style: CustomTextStyles.bodyMediumBluegray300,
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 19.h,
                          top: 20.v,
                          bottom: 4.v,
                        ),
                        child: Column(
                          children: [
                            Text(
                              "Thu",
                              style: theme.textTheme.bodyMedium,
                            ),
                            SizedBox(height: 8.v),
                            Container(
                              width: 46.h,
                              padding: EdgeInsets.symmetric(
                                horizontal: 6.h,
                                vertical: 2.v,
                              ),
                              decoration: AppDecoration.fillDeepOrange.copyWith(
                                borderRadius: BorderRadiusStyle.circleBorder9,
                              ),
                              child: Text(
                                "101-150",
                                style: theme.textTheme.bodySmall,
                              ),
                            ),
                            SizedBox(height: 15.v),
                            CustomImageView(
                              imagePath: ImageConstant.imgImage14,
                              height: 22.v,
                              width: 27.h,
                            ),
                            SizedBox(height: 15.v),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "34",
                                    style: CustomTextStyles.bodyMediumff000000,
                                  ),
                                  TextSpan(
                                    text: "°",
                                    style: CustomTextStyles.bodyMediumff000000,
                                  ),
                                ],
                              ),
                              textAlign: TextAlign.left,
                            ),
                            SizedBox(height: 7.v),
                            Text(
                              "24°",
                              style: CustomTextStyles.bodyMediumBluegray300,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 22.v),
                CustomImageView(
                  imagePath: ImageConstant.imgArrowIcon,
                  height: 19.v,
                  width: 22.h,
                  margin: EdgeInsets.only(left: 147.h),
                ),
                SizedBox(height: 6.v),
              ],
            ),
          ),
          SizedBox(height: 49.v),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 35.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomOutlinedButton(
                  width: 112.h,
                  text: "ADD PLACE",
                ),
                CustomOutlinedButton(
                  width: 112.h,
                  text: "MANAGE",
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
