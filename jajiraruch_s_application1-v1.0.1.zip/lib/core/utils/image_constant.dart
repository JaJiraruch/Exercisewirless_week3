class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgBg = '$imagePath/img_bg.png';

  static String imgImage29 = '$imagePath/img_image_29.png';

  static String imgImage28 = '$imagePath/img_image_28.png';

  static String imgSearchIcon = '$imagePath/img_search_icon.png';

  static String imgNotificationIcon = '$imagePath/img_notification_icon.png';

  static String imgGroup5 = '$imagePath/img_group_5.svg';

  static String imgSunIcon = '$imagePath/img_sun_icon.png';

  static String imgArrowIconUp = '$imagePath/img_arrow_icon_up.png';

  static String imgBadIcon = '$imagePath/img_bad_icon.png';

  static String imgImage12 = '$imagePath/img_image_12.png';

  static String imgImage13 = '$imagePath/img_image_13.png';

  static String imgImage14 = '$imagePath/img_image_14.png';

  static String imgArrowIcon = '$imagePath/img_arrow_icon.png';

  static String imgLocationIcon = '$imagePath/img_location_icon.png';

  static String imgMapIcon = '$imagePath/img_map_icon.png';

  static String imgRankIcon = '$imagePath/img_rank_icon.png';

  static String imgNewsIcon = '$imagePath/img_news_icon.png';

  static String imgAccountIcon = '$imagePath/img_account_icon.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
