import 'package:flutter/material.dart';
import 'package:jajiraruch_s_application1/presentation/location_list_container_screen/location_list_container_screen.dart';
import 'package:jajiraruch_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String locationListPage = '/location_list_page';

  static const String locationListContainerScreen =
      '/location_list_container_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    locationListContainerScreen: (context) => LocationListContainerScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
