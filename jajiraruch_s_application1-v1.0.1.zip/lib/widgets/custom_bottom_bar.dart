import 'package:flutter/material.dart';
import 'package:jajiraruch_s_application1/core/app_export.dart';

class CustomBottomBar extends StatefulWidget {
  CustomBottomBar({this.onChanged});

  Function(BottomBarEnum)? onChanged;

  @override
  CustomBottomBarState createState() => CustomBottomBarState();
}

class CustomBottomBarState extends State<CustomBottomBar> {
  int selectedIndex = 0;

  List<BottomMenuModel> bottomMenuList = [
    BottomMenuModel(
      icon: ImageConstant.imgLocationIcon,
      activeIcon: ImageConstant.imgLocationIcon,
      type: BottomBarEnum.Locationicon,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgMapIcon,
      activeIcon: ImageConstant.imgMapIcon,
      type: BottomBarEnum.Mapicon,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgRankIcon,
      activeIcon: ImageConstant.imgRankIcon,
      type: BottomBarEnum.Rankicon,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNewsIcon,
      activeIcon: ImageConstant.imgNewsIcon,
      type: BottomBarEnum.Newsicon,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgAccountIcon,
      activeIcon: ImageConstant.imgAccountIcon,
      type: BottomBarEnum.Accounticon,
    )
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 76.v,
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedFontSize: 0,
        elevation: 0,
        currentIndex: selectedIndex,
        type: BottomNavigationBarType.fixed,
        items: List.generate(bottomMenuList.length, (index) {
          return BottomNavigationBarItem(
            icon: CustomImageView(
              imagePath: bottomMenuList[index].icon,
              height: 37.adaptSize,
              width: 37.adaptSize,
            ),
            activeIcon: CustomImageView(
              imagePath: bottomMenuList[index].activeIcon,
              height: 40.v,
              width: 32.h,
            ),
            label: '',
          );
        }),
        onTap: (index) {
          selectedIndex = index;
          widget.onChanged?.call(bottomMenuList[index].type);
          setState(() {});
        },
      ),
    );
  }
}

enum BottomBarEnum {
  Locationicon,
  Mapicon,
  Rankicon,
  Newsicon,
  Accounticon,
}

class BottomMenuModel {
  BottomMenuModel({
    required this.icon,
    required this.activeIcon,
    required this.type,
  });

  String icon;

  String activeIcon;

  BottomBarEnum type;
}

class DefaultWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.all(10),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Please replace the respective Widget here',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
